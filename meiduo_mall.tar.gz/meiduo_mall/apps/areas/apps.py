from django.apps import AppConfig


class AreasConfig(AppConfig):
    name = 'areas'
