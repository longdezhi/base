"""
当前apps包里面，用来存放django工程的应用！
"""